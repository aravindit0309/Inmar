﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductOfferApi.Models
{
    public class Product
    {
        public Product(string _productName, decimal _price, string _description)
        {
            ProductName = _productName;
            Price = _price;
            Description = _description;
        }

        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
    }
}