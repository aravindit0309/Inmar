﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ProductOfferApi.Models;

namespace ProductOfferApi.Service
{
    public class OfferService
    {
        private List<Product> inventory;

        public OfferService()
        {
            //AddProduct();
        }

        public List<Product> GetAllProduct() // It should get product detail as a parameter
        {
            //Making this method to return list of products due to unavailablity of database
            //ideally it should get value from the db
            inventory.Add(new Product( "P1", 1000, "P1 desc"));
            inventory.Add(new Product("P2", 200, "P2 desc"));
            inventory.Add(new Product("P3", 400, "P3 desc"));
            inventory.Add(new Product("P4", 700, "P4 desc"));
            inventory.Add(new Product("P5", 600, "p5 desc"));
            inventory.Add(new Product("P6", 800, "P6 desc" ));

            return inventory;
        }

        public void AddProduct(Product product)
        {
            inventory.Add(new Product("P1", 1000, "P1 desc"));
        }

        public List<Product> GetTodaysOffer()
        {
            return inventory;// should be done based on some logic in the service layer or from database
        }
    }
}