﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleMathProject
{
    class Program
    {
        static void Main(string[] args)
        {
            string userInput = string.Empty;
            int outRemainder3;
            int outRemainder5;
            //Console.WriteLine("Enter Input: ");
            //userInput = Console.ReadLine();
            for (int i = 0; i <= 100; i++)
            {
                Math.DivRem(i, 3, out outRemainder3);
                Math.DivRem(i, 5, out outRemainder5);
                if(outRemainder3 == 0 && outRemainder5 ==0)
                {
                    Console.WriteLine("fizzbuzz");
                }
                else if(outRemainder3 == 0)
                {
                    Console.WriteLine("fizz");
                }
                else if(outRemainder5 == 0)
                {
                    Console.WriteLine("buzz");
                }    
            }
            Console.ReadLine();

        }
    }
}
